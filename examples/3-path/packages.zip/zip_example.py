def hello(name):
    print('ZIP:', 'Hello', name)
