def multiplication(x, y):
    return x * y
