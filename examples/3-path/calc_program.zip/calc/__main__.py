from . import multiplication


def main():
    print('x * y = ?')
    x = int(input('x> '))
    y = int(input('y> '))
    print(multiplication(x, y))


if __name__ == '__main__':
    main()
