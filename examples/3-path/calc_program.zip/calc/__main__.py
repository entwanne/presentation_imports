import os

from . import multiplication


def main():
    x = int(os.environ['X'])
    y = int(os.environ['Y'])
    print(multiplication(x, y))


if __name__ == '__main__':
    main()
