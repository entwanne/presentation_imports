def hello(name):
    print('TAR:', 'Hello', name)
